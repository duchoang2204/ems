// DTO SearchE1
export interface SearchE1RequestDto {
  fromDate: Date | null;    // UI: DatePicker → API: string YYYYMMDD
  toDate: Date | null;      // UI: DatePicker → API: string YYYYMMDD
  mabcDong: string;         // UI: string → DB: mabc_kt (number)
  mabcNhan: string;         // UI: string → DB: mabc (number)
  chthu: string;           // UI: string → DB: number
  tuiso: string;           // UI: string → DB: number
  khoiluong?: string;      // UI: string → DB: number
  page?: number;
  limit?: number;
}

export interface SearchE1ResponseDto {
  data: Array<{
    mae1: string;
    ngay: string;
    mabcDong: string;
    mabcNhan: string;
    chthu: string;
    tuiso: string;
    khoiluong: string;
  }>;
  totalCount: number;
  totalWeight: number;
  currentPage: number;
  totalPages: number;
}

// DTO GetE1Details
export interface GetE1DetailsRequestDto {
  mae1: string;
  fromDate: Date | null;    // UI: DatePicker → API: string YYYYMMDD
  toDate: Date | null;      // UI: DatePicker → API: string YYYYMMDD
  mabcDong: string;         // UI: string → DB: mabc_kt (number)
  mabcNhan: string;         // UI: string → DB: mabc (number)
  chthu: string;           // UI: string → DB: number
  tuiso: string;           // UI: string → DB: number
}

export interface GetE1DetailsResponseDto {
  e1Details: E1DetailInfo[];
  bd10Details: E1BD10Info[];
}

// SQL Server Entities - giữ nguyên interface
export interface E1DetailInfo {
  stt: number;
  ngayCT: string;
  gioDongCT: string;
  buuCucDong: string;
  buuCucNhan: string;
  thongTinCT: string;
}

export interface E1BD10Info {
  stt: number;
  ngayBD10: string;
  ngayXacNhanDi: string;
  buuCucGiao: string;
  buuCucNhan: string;
  lanLapMaBD10: string;
}
