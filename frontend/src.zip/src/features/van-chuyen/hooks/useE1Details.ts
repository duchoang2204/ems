// Hook dùng React Query → call API Get E1 Details
// Chuyển đổi kiểu dữ liệu trước khi gửi API

import { useMutation } from '@tanstack/react-query';
import type { GetE1DetailsRequestDto, GetE1DetailsResponseDto } from '../types/vanChuyen.types';
import { formatDateToYyyymmdd } from '../../../utils/dateUtils';
import axiosInstance from '../../../api/axiosConfig';

export const useE1Details = () => {
  return useMutation({
    mutationKey: ['getE1Details'],
    mutationFn: async (params: GetE1DetailsRequestDto): Promise<GetE1DetailsResponseDto> => {
      const payload = {
        ...params,
        fromDate: params.fromDate ? formatDateToYyyymmdd(params.fromDate) : null,
        toDate: params.toDate ? formatDateToYyyymmdd(params.toDate) : null,
        mabcDong: params.mabcDong || '',  // Không parse sang number
        mabcNhan: params.mabcNhan || '',  // Không parse sang number
        chthu: params.chthu ? parseInt(params.chthu) : 0,
        tuiso: params.tuiso ? parseInt(params.tuiso) : 0
      };

      const response = await axiosInstance.post<GetE1DetailsResponseDto>('/van-chuyen/e1/details', payload);
      return response.data;
    }
  });
};
