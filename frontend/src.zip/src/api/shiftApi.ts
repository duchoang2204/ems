import axiosInstance from './axiosConfig';

export const checkShift = async (g_mabc: string) => {
  const res = await axiosInstance.post('/shift/check', { g_mabc });
  return res.data;
};
