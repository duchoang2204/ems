export interface Shift {
  ngay: number;
  ca: number;
  tenca: string;
  ngayBatDau: number;
  gioBatDau: number;
  ngayKetThuc: number;
  gioKetThuc: number;
  active: number;
  idCa: number;
  nvXacNhanCa: string;
  mabcKt: number;
  autoXnd: number;
  dateLog?: string;
}
