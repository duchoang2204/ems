export interface User {
  manv: number;
  tennv: string;
  mucdo: number;
  ketoan: number;
  // thêm trường nếu backend trả về
}
