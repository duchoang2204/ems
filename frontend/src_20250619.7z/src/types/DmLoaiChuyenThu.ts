export interface DmLoaiChuyenThu {
    id_loai_ct: number       // ID loại chuyến thư
    ten_loai_ct: string      // Tên loại chuyến thư
    dien_giai: string        // Diễn giải thêm
  }
  