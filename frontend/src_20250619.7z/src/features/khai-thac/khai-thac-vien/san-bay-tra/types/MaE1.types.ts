// src/features/khai-thac/khai-thac-vien/san-bay-tra/types/MaE1.types.ts

export interface MaE1 {
    mae1: string;
    khoiluong: number;
    ghichu: string;
    hanhtrinh: string;
    noidung: string;
    trangthai: string;
  }
  