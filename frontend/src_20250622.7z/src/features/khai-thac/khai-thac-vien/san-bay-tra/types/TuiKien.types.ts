// src/features/khai-thac/khai-thac-vien/san-bay-tra/types/TuiKien.types.ts

export interface TuiKien {
    mabc_kt: number;
    mabc: number;
    ngay: number;
    chthu: number;
    tuiso: number;
    id_e2: string;
    khoiluong: number;
    ischon: number;
  }
  