import 'reflect-metadata';
import { container } from 'tsyringe';

// Import module containers
import '../modules/auth/di/container';
import '../modules/shift/di/container';
