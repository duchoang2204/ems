import { injectable, inject } from 'tsyringe';
import { LoginRequestDto } from '../dto/login.dto';
import { LoginResponseDto } from '../dto/login-response.dto';
import { AuthService } from '../services/implementations/auth.service';
import { IUserRepository } from '../domain/repositories/auth.repository.interface';
import { JwtTokenService } from '../services/implementations/jwt-token.service';


@injectable()
export class LoginUseCase {
  constructor(
    @inject(AuthService) private authService: AuthService,
    @inject('UserRepository') private userRepository: IUserRepository,
    @inject(JwtTokenService) private jwtTokenService: JwtTokenService
  ) {}
  
  async execute(request: LoginRequestDto): Promise<LoginResponseDto> {
    try {
      // 1. Lấy user từ repo (truyền g_mabc, manv, mkhau)
      const user = await this.userRepository.findByManv(request.g_mabc, request.manv, request.mkhau);
      if (!user) {
        throw new Error('INVALID_CREDENTIALS');
      }

      // 2. Tạo token
      const token = this.jwtTokenService.generateToken(user);

      // 3. Trả về response
      return {
        user: user,
        token: token
      };
    } catch (error) {
      if (error instanceof Error) {
        throw error; // Re-throw stored procedure errors
      }
      throw new Error('SYSTEM_ERROR');
    }
  }
} 