// REST API controller cho feature van-chuyen
// Route: /van-chuyen/e1/search → search list E1
// Route: /van-chuyen/e1/details → lấy chi tiết E1

import { Request, Response, Router } from 'express';
import { container } from 'tsyringe';
import { SearchE1UseCase } from '../../../application/use-cases/van-chuyen/SearchE1UseCase';
import { GetE1DetailsUseCase } from '../../../application/use-cases/van-chuyen/GetE1DetailsUseCase';
import { VanChuyenService } from '../../../application/services/VanChuyenService';

const router = Router();

router.post('/e1/search', async (req: Request, res: Response) => {
  try {
    const useCase = container.resolve(SearchE1UseCase);
    const result = await useCase.execute(req.body);
    res.json(result);
  } catch (err: any) {
    console.error('Error /van-chuyen/e1/search:', err);
    res.status(500).json({ message: err.message || 'Internal Server Error' });
  }
});

router.post('/e1/details', async (req: Request, res: Response) => {
  try {
    const useCase = container.resolve(GetE1DetailsUseCase);
    const result = await useCase.execute(req.body);
    res.json(result);
  } catch (err: any) {
    console.error('Error /van-chuyen/e1/details:', err);
    res.status(500).json({ message: err.message || 'Internal Server Error' });
  }
});

// Route API POSName → GET /van-chuyen/pos-name/:posCode
router.get('/pos-name/:posCode', async (req: Request, res: Response) => {
  try {
    const posCode = req.params.posCode;
    const service = container.resolve(VanChuyenService);
    const posName = await service.getPOSName(posCode);
    res.json({ posCode, posName });
  } catch (err: any) {
    console.error('Error /van-chuyen/pos-name/:posCode:', err);
    res.status(500).json({ message: err.message || 'Internal Server Error' });
  }
});

export default router;
