// Combine router cho toàn bộ REST API

import { Router } from 'express';
import vanChuyenRouter from './VanChuyenController';

const router = Router();

// Mount router cho feature van-chuyen
router.use('/van-chuyen', vanChuyenRouter);

export default router;
