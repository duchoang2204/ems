// Repository → thao tác SQL Server → get BD10 details
// Kết nối SQL Server → config qua ENV

import sql from 'mssql';
import { injectable } from 'tsyringe';
import { GetE1DetailsRequestDto } from '../../../application/dto/van-chuyen/GetE1DetailsRequestDto';
import { sqlServerPool100916 } from '../../../shared/config/sqlServer.config';
import { E1BD10Info } from '../../../domain/entities/van-chuyen/E1Entity';

@injectable()
export class VanChuyenRepositorySQLServer {
  async getBD10Details(request: GetE1DetailsRequestDto): Promise<E1BD10Info[]> {
    const { fromDate, toDate, mabcDong, mabcNhan, chthu, tuiso } = request;

    const pool = await sqlServerPool100916;

    const bc37IndexSql = `
      SELECT BC37Index
      FROM MailtripTransportPostBag
      WHERE Year BETWEEN @fromDate AND @toDate
        AND FromPOSCode = @mabcDong
        AND ToPOSCode = @mabcNhan
        AND MailTripNumber = @chthu
        AND PostBagIndex = @tuiso
    `;

    const bc37IndexResult = await pool.request()
      .input('fromDate', sql.VarChar(8), fromDate)
      .input('toDate', sql.VarChar(8), toDate)
      .input('mabcDong', sql.VarChar(6), mabcDong)
      .input('mabcNhan', sql.VarChar(6), mabcNhan)
      .input('chthu', sql.VarChar(4), chthu)
      .input('tuiso', sql.Int, tuiso)
      .query(bc37IndexSql);

    const bc37Indexes = bc37IndexResult.recordset.map((row: any) => row.BC37Index);

    if (bc37Indexes.length === 0) return [];

    const bc37Sql = `
      SELECT BC37Date, SendingTime, FromPOSCode, ToPOSCode, BC37Index, BC37Code, ConfirmDate
      FROM BC37
      WHERE BC37Date BETWEEN @fromDate AND @toDate
        AND FromPOSCode = @mabcDong
        AND ToPOSCode = @mabcNhan
        AND BC37Index IN (${bc37Indexes.join(',')})
      ORDER BY BC37Date DESC, ConfirmDate DESC
    `;

    const bc37Result = await pool.request()
      .input('fromDate', sql.VarChar(8), fromDate)
      .input('toDate', sql.VarChar(8), toDate)
      .input('mabcDong', sql.VarChar(6), mabcDong)
      .input('mabcNhan', sql.VarChar(6), mabcNhan)
      .query(bc37Sql);

    return bc37Result.recordset.map((row: any, index: number) => ({
      stt: index + 1,
      ngayBD10: row.BC37Date,
      ngayXacNhanDi: row.SendingTime ? new Date(row.SendingTime).toLocaleDateString('vi-VN') : '',
      buuCucGiao: `${row.FromPOSCode}`, // map thêm POSName ở FE
      buuCucNhan: `${row.ToPOSCode}`,
      lanLapMaBD10: `${row.BC37Index} / ${row.BC37Code}`
    }));
  }

  async getPOSName(posCode: string): Promise<string> {
    const pool = await sqlServerPool100916;
  
    const sqlQuery = `
      SELECT POSName
      FROM POS
      WHERE POSCode = @posCode
    `;
  
    const result = await pool.request()
      .input('posCode', sql.VarChar(6), posCode)
      .query(sqlQuery);
  
    const posRow = result.recordset?.[0];
  
    if (!posRow) {
      return '(Không tìm thấy)';
    }
  
    return posRow.POSName || '(Không rõ)';
  }
  
}
