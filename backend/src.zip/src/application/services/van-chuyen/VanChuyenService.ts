// Application Service
// Thực hiện logic orchestrate → gọi Repo + DomainService

import { inject, injectable } from 'tsyringe';
import { VanChuyenRepositoryOracle } from '../../../infrastructure/repositories/van-chuyen/VanChuyenRepositoryOracle';
import { VanChuyenDomainService } from '../../../domain/services/van-chuyen/VanChuyenDomainService';
import { SearchE1RequestDto } from '../../dto/van-chuyen/SearchE1RequestDto';
import { SearchE1ResponseDto } from '../../dto/van-chuyen/SearchE1ResponseDto';
import { GetE1DetailsRequestDto } from '../../dto/van-chuyen/GetE1DetailsRequestDto';
import { GetE1DetailsResponseDto } from '../../dto/van-chuyen/GetE1DetailsResponseDto';
import { VanChuyenRepositorySQLServer } from '../../../infrastructure/repositories/van-chuyen/VanChuyenRepositorySQLServer';

@injectable()
export class VanChuyenService {
  constructor(
    @inject(VanChuyenRepositoryOracle) private oracleRepo: VanChuyenRepositoryOracle,
    @inject(VanChuyenRepositorySQLServer) private sqlServerRepo: VanChuyenRepositorySQLServer,
    @inject(VanChuyenDomainService) private domainService: VanChuyenDomainService
  ) {}

  async searchE1(request: SearchE1RequestDto): Promise<SearchE1ResponseDto> {
    return await this.oracleRepo.searchE1(request);
  }

  async getE1Details(request: GetE1DetailsRequestDto): Promise<GetE1DetailsResponseDto> {
    // Query chuyến thư + BD10 từ Repo
    const e1Details = await this.oracleRepo.getE1Details(request);
    const bd10Details = await this.sqlServerRepo.getBD10Details(request);

    // Enrich nếu cần (VD: sort, format)
    const enrichedE1Details = this.domainService.enrichE1Details(e1Details);

    return {
      e1Details: enrichedE1Details,
      bd10Details
    };
  }

  async getPOSName(posCode: string): Promise<string> {
    // Call SQLServerRepo để lấy POSName
    const posName = await this.sqlServerRepo.getPOSName(posCode);
    return posName;
  }  
}
