import { container } from 'tsyringe';
import { SHIFT_REPOSITORY, SHIFT_SERVICE } from './di/tokens';
import { OracleShiftRepository } from './data-access/oracle/shift.repository';
import { SQLServerShiftRepository } from './data-access/sqlserver/shift.repository'; // nếu có
import { ShiftService } from './services/implementations/shift.service';
import { getCurrentDbType } from '@/core/utils/dbSelector.util';
import { DatabaseType } from '@/config/constants/common';

export function registerShiftModule() {
  const dbType = getCurrentDbType();

  if (dbType === DatabaseType.ORACLE) {
    container.register(SHIFT_REPOSITORY, { useClass: OracleShiftRepository });
  } else {
    container.register(SHIFT_REPOSITORY, { useClass: SQLServerShiftRepository });
  }

  container.register(SHIFT_SERVICE, { useClass: ShiftService });
}
