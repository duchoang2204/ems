// 📁 modules/auth/domain/repositories/auth.repository.interface.ts
import { User } from '../entities/user.entity';

export interface IAuthRepository {
  findByManv(g_mabc: string, manv: number, mkhau: string): Promise<User | null>;
  findByUsername(g_mabc: string, username: string): Promise<User | null>;
}