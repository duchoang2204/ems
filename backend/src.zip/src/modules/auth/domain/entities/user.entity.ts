// 📁 modules/auth/domain/entities/user.entity.ts
export class User {
  constructor(
    public manv: number,
    public tennv: string,
    public mkhau: string,
    public mucdo: number,
    public ketoan: number,
    public g_mabc: string
  ) {}

  static create(data: User): User {
    return new User(
      data.manv,
      data.tennv,
      data.mkhau,
      data.mucdo,
      data.ketoan,
      data.g_mabc
    );
  }

  getRoleName(): string {
    switch (this.mucdo) {
      case 1: return 'Nhân viên khai thác';
      case 2: return 'Kiểm soát viên';
      case 7: return 'Kế toán';
      case 9: return 'Admin';
      default: return 'Không rõ';
    }
  }
}