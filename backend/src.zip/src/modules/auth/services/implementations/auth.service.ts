// 📁 modules/auth/services/implementations/auth.service.ts
import { inject, injectable } from 'tsyringe';
import { IAuthService } from '../interfaces/auth.service.interface';
import { LoginDto } from '../../dto/login.dto';
import { AuthResponseDto } from '../../dto/auth.response.dto';
import { IAuthRepository } from '../../domain/repositories/auth.repository.interface';
import { AUTH_REPOSITORY } from '../../di/tokens';
import { ITokenService } from '@/infrastructure/services/auth/ITokenService';
import { User } from '../../domain/entities/user.entity';
import { JwtTokenService } from '../implementations/jwt-token.service';


@injectable()
export class AuthService implements IAuthService {
  constructor(
    @inject(AUTH_REPOSITORY)
    private readonly authRepo: IAuthRepository,

    @inject(JwtTokenService)
    private readonly tokenService: ITokenService
  ) {}

  async login(dto: LoginDto): Promise<AuthResponseDto> {
    const user = await this.authRepo.findByManv(dto.g_mabc, dto.manv, dto.mkhau);

    if (!user) {
      throw new Error('INVALID_CREDENTIALS');
    }

    if (!user.verifyPassword(dto.mkhau)) {
      throw new Error('INVALID_CREDENTIALS');
    }

    const token = this.tokenService.generateToken(user);

    return {
      token,
      manv: user.manv,
      tennv: user.tennv,
      mucdo: user.mucdo,
      ketoan: user.ketoan,
      g_mabc: user.g_mabc,
      roleName: user.getRoleName?.() || 'Không rõ',
    };
  }
}