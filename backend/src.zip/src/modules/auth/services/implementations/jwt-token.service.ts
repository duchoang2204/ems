import { injectable } from 'tsyringe';
import jwt, { SignOptions } from 'jsonwebtoken';

import { User } from '../../../domain/entities/user.entity';
import { JWT_SECRET, JWT_EXPIRES_IN } from '@/config/jwt';
import { ITokenService } from '../interfaces/auth.token.interface';

@injectable()
export class JwtTokenService implements ITokenService {
  generateToken(user: User): string {
    const payload = {
      manv: user.manv,
      tennv: user.tennv,
      mucdo: user.mucdo,
      ketoan: user.ketoan,
      g_mabc: user.g_mabc
    };

    const options: SignOptions = {
      expiresIn: JWT_EXPIRES_IN
    };

    return jwt.sign(payload, JWT_SECRET, options);
  }
}
