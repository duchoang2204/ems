import { User } from '../../domain/entities/user.entity';

export interface ITokenService {
  generateToken(user: User): string;
}
