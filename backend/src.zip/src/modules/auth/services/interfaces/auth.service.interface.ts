// 📁 modules/auth/services/interfaces/auth.service.interface.ts
import { LoginDto } from '../../dto/login.dto';
import { AuthResponseDto } from '../../dto/auth.response.dto';

export interface IAuthService {
  login(dto: LoginDto): Promise<AuthResponseDto>;
}