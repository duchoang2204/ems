export const AUTH_REPOSITORY = 'AuthRepository';
export const AUTH_SERVICE = 'AuthService';
export const TOKEN_SERVICE = 'TokenService'; // 👈 THÊM DÒNG NÀY
