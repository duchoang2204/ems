// 📁 modules/auth/dto/auth.response.dto.ts
export interface AuthResponseDto {
  token: string;
  manv: number;
  tennv: string;
  mucdo: number;
  ketoan: number;
  g_mabc: string;
  roleName: string;
}