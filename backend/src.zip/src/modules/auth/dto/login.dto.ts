// 📁 modules/auth/dto/login.dto.ts
export interface LoginDto {
  g_mabc: string;
  manv: number;
  mkhau: string;
}