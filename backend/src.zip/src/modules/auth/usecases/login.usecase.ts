// 📁 modules/auth/usecases/login.usecase.ts
import { inject, injectable } from 'tsyringe';
import { IAuthService } from '../services/interfaces/auth.service.interface';
import { AUTH_SERVICE } from '../di/tokens';
import { LoginDto } from '../dto/login.dto';
import { AuthResponseDto } from '../dto/auth.response.dto';

@injectable()
export class LoginUseCase {
  constructor(
    @inject(AUTH_SERVICE)
    private readonly authService: IAuthService
  ) {}

  async execute(dto: LoginDto): Promise<AuthResponseDto> {
    return this.authService.login(dto);
  }
}