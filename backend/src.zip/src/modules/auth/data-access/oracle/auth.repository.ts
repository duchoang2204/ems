// 📁 modules/auth/data-access/oracle/auth.repository.ts
import { injectable } from 'tsyringe';
import { IAuthRepository } from '../../domain/repositories/auth.repository.interface';
import { User } from '../../domain/entities/user.entity';
import { getConnectionByMaBC } from '@/config/database/oracle.config';
import oracledb from 'oracledb';

interface OracleUser {
  MANV: number;
  TENNV: string;
  MKHAU: string;
  MUCDO: number;
  KETOAN: number;
}

@injectable()
export class OracleAuthRepository implements IAuthRepository {
  async findByManv(g_mabc: string, manv: number, mkhau: string): Promise<User | null> {
    const conn = await getConnectionByMaBC(g_mabc);
    try {
      const result = await conn.execute(
        `BEGIN
          W_SP_AUTH_LOGIN(:p_g_mabc, :p_manv, :p_mkhau, :p_user, :p_error);
        END;`,
        {
          p_g_mabc: Number(g_mabc),
          p_manv: manv,
          p_mkhau: mkhau,
          p_user: { dir: oracledb.BIND_OUT, type: oracledb.CURSOR },
          p_error: { dir: oracledb.BIND_OUT, type: oracledb.STRING, maxSize: 100 }
        }
      );

      const outBinds = result.outBinds as any;
      if (outBinds.p_error) {
        throw new Error(outBinds.p_error);
      }

      const resultSet = outBinds.p_user as oracledb.ResultSet<any>;
      const row = await resultSet.getRow();
      await resultSet.close();

      if (!row) return null;

      const user = row as OracleUser;
      return new User(
        user.MANV,
        user.TENNV,
        user.MKHAU,
        user.MUCDO,
        user.KETOAN,
        g_mabc
      );
    } finally {
      await conn.close();
    }
  }

  async findByUsername(g_mabc: string, username: string): Promise<User | null> {
    const conn = await getConnectionByMaBC(g_mabc);
    try {
      const result = await conn.execute(
        `SELECT manv, tennv, mkhau, mucdo, ketoan FROM nvien WHERE tennv = :username`,
        { username }
      );

      if (!result.rows || result.rows.length === 0) return null;

      const [manv, tennv, mkhau, mucdo, ketoan] = result.rows[0] as any[];
      return new User(manv, tennv, mkhau, mucdo, ketoan, g_mabc);
    } finally {
      await conn.close();
    }
  }
}