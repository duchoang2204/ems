// 📁 modules/auth/controllers/auth.validator.ts
import { Request, Response, NextFunction } from 'express';
import { LoginSchema } from '../../schemas/auth.schema';


export function validateLogin(req: Request, res: Response, next: NextFunction) {
  const result = LoginSchema.safeParse(req.body);

  if (!result.success) {
    return res.status(400).json({
      ok: false,
      code: 'INVALID_INPUT',
      msg: 'Dữ liệu đầu vào không hợp lệ!',
      errors: result.error.flatten(),
    });
  }

  next();
}