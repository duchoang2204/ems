// 📁 modules/auth/interfaces/routes/auth.route.ts
import { Router } from 'express';
import { container } from 'tsyringe';
import { AuthController } from '../controllers/auth.controller';

const router = Router();
const controller = container.resolve(AuthController);

router.post('/login', (req, res) => controller.login(req, res));

export default router;
