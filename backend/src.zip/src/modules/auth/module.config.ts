import { container } from 'tsyringe';
import {
  AUTH_REPOSITORY,
  AUTH_SERVICE,
  TOKEN_SERVICE
} from './di/tokens';

import { OracleAuthRepository } from './data-access/oracle/auth.repository';
import { SQLServerAuthRepository } from './data-access/sqlserver/auth.repository';
import { AuthService } from './services/implementations/auth.service';
import { JwtTokenService } from './services/implementations/jwt-token.service';
import { ITokenService } from './services/interfaces/auth.token.interface';

import { getCurrentDbType } from '@/core/utils/dbSelector.util';
import { DatabaseType } from '@/config/constants/common';

export function registerAuthModule() {
  const dbType = getCurrentDbType();

  if (dbType === DatabaseType.ORACLE) {
    container.register(AUTH_REPOSITORY, { useClass: OracleAuthRepository });
  } else {
    container.register(AUTH_REPOSITORY, { useClass: SQLServerAuthRepository });
  }

  container.register(AUTH_SERVICE, { useClass: AuthService });
  container.register<ITokenService>(TOKEN_SERVICE, { useClass: JwtTokenService });
}
