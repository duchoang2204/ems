// 📁 modules/auth/schemas/auth.schema.ts
import { z } from 'zod';

export const LoginSchema = z.object({
  g_mabc: z.string().min(5),
  manv: z.number().int().positive(),
  mkhau: z.string().min(1),
});