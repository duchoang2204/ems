// core/database/sqlserver/sp-executor.ts
import { executeSP } from '@/infrastructure/utils/dbUtil'; // hoặc cách bạn đang làm
import { IStoredProcedureExecutor } from '../base/base.sp-executor';

export const sqlServerSpExecutor: IStoredProcedureExecutor = {
  async execute(spName, params) {
    return await executeSP(spName, params); // wrapper gốc bạn đã có
  },
};
