// core/utils/dbSelector.util.ts
import { config } from '@/config/app';
import { DatabaseType } from '../../config/constants/common';


export function getCurrentDbType(): DatabaseType {
  return config.databaseType as DatabaseType; // đảm bảo ENV = 'oracle' | 'sqlserver'
}
