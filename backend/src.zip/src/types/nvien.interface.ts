export interface User {
  manv: number;
  tennv: string;
  mkhau: string;
  mucdo: number;
  ketoan: number;
}
