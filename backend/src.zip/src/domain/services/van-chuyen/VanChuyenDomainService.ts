// DomainService → xử lý logic domain thuần
// VD: sort E1Details

import { injectable } from 'tsyringe';
import { E1DetailInfo } from '../../entities/van-chuyen/E1Entity';

@injectable()
export class VanChuyenDomainService {
  enrichE1Details(details: E1DetailInfo[]): E1DetailInfo[] {
    return details.sort((a, b) => {
      // Sort theo ngày CT rồi đến giờ đóng
      if (a.ngayCT !== b.ngayCT) {
        return a.ngayCT.localeCompare(b.ngayCT);
      }
      return a.gioDongCT.localeCompare(b.gioDongCT);
    });
  }
}
