// Domain Entity → E1DetailInfo + E1BD10Info

export interface E1DetailInfo {
    stt: number;
    ngayCT: string;      // 'dd/MM/yyyy'
    gioDongCT: string;   // 'HH:mm'
    buuCucDong: string;  // POSCode → tên bưu cục lấy từ API POSName
    buuCucNhan: string;  // POSCode → tên bưu cục lấy từ API POSName
    thongTinCT: string;  // 'E / chthu / tuiso'
  }
  
  export interface E1BD10Info {
    stt: number;
    ngayBD10: string;      // 'dd/MM/yyyy'
    ngayXacNhanDi: string; // 'dd/MM/yyyy'
    buuCucGiao: string;    // POSCode → tên bưu cục
    buuCucNhan: string;    // POSCode → tên bưu cục
    lanLapMaBD10: string;  // 'BC37Index / BC37Code'
  }
  