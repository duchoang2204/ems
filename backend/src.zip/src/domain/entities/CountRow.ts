// Domain Entity → CountRow
export interface CountRow {
  TOTALCOUNT: number;
  TOTALWEIGHT: number;
}
