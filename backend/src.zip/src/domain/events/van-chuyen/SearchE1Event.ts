// Event Audit Search E1

import { SearchE1RequestDto } from '../../../application/dto/van-chuyen/SearchE1RequestDto';

export class SearchE1Event {
  constructor(public readonly request: SearchE1RequestDto, public readonly resultCount: number) {}
}
