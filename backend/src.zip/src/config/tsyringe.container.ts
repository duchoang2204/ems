// 📁 src/config/tsyringe.container.ts
import 'reflect-metadata';
import { container } from 'tsyringe';
import { registerAuthModule } from '@/modules/auth/module.config';
import { registerShiftModule } from '@/modules/shift/module.config';

registerAuthModule();
registerShiftModule();