// 📁 src/config/database/oracle.config.ts
import oracledb, { ConnectionAttributes } from 'oracledb';

try {
  oracledb.initOracleClient({ libDir: 'C:\\oracle\\instantclient_19_26' });
} catch (err) {
  console.log('Oracle Client đã được khởi tạo hoặc đã tồn tại.');
}

oracledb.autoCommit = true;
oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;

export const dbConfigHNLT: ConnectionAttributes = {
  user: process.env.DB_HNLT_USER,
  password: process.env.DB_HNLT_PASSWORD,
  connectString: process.env.DB_HNLT_CONNECT_STRING,
};

export const dbConfigHNNT: ConnectionAttributes = {
  user: process.env.DB_HNNT_USER,
  password: process.env.DB_HNNT_PASSWORD,
  connectString: process.env.DB_HNNT_CONNECT_STRING,
};

export const dbConfigHCMLT: ConnectionAttributes = {
  user: process.env.DB_HCMLT_USER,
  password: process.env.DB_HCMLT_PASSWORD,
  connectString: process.env.DB_HCMLT_CONNECT_STRING,
};

export const dbConfigMap: Record<string, ConnectionAttributes> = {
  '100916': dbConfigHNLT,
  '101000': dbConfigHNNT,
  '700916': dbConfigHCMLT,
};

export async function getOracleConnectionByMaBC(mabc: string) {
  const dbConfig = dbConfigMap[mabc];
  if (!dbConfig) throw new Error('Mã bưu cục không hợp lệ!');
  return await oracledb.getConnection(dbConfig);
}
