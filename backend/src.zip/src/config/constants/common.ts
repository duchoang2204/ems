// 📁 src/config/constants/common.ts
export enum DatabaseType {
    ORACLE = 'oracle',
    SQLSERVER = 'sqlserver',
  }