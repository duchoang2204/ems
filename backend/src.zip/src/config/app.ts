// 📁 src/config/app.ts
import dotenv from 'dotenv';
dotenv.config();

export const AppConfig = {
  port: process.env.PORT || 4000,
  jwt: {
    secret: process.env.JWT_SECRET || 'your-secret-key',
    expiresIn: process.env.JWT_EXPIRES_IN || '24h',
  },
  databaseType: process.env.DATABASE_TYPE || 'oracle', // 'oracle' | 'sqlserver'
};