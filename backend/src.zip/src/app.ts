import 'reflect-metadata'; // Bắt buộc phải có khi dùng tsyringe
import express from 'express';
import cors from 'cors';

// 🔁 Import các route từ module
import authRoutes from './modules/auth/interfaces/routes/auth.route';
import shiftRoutes from './modules/shift/interfaces/routes/shift.route';

// ✅ Khởi tạo ứng dụng
const app = express();

// ✅ Middleware
app.use(cors());
app.use(express.json());

// ✅ Mount routes theo namespace
app.use('/api/auth', authRoutes);
app.use('/api/shift', shiftRoutes);

export default app;
