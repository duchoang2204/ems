export const AUTH_TOKENS = {
  LoginUseCase: 'LoginUseCase',
  AuthService: 'AuthService',
  AuthRepository: 'AuthRepository',
  JwtTokenService: 'JwtTokenService'
} as const; 