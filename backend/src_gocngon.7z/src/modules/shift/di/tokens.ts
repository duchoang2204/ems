export const SHIFT_TOKENS = {
  CheckCurrentShiftUseCase: 'CheckCurrentShiftUseCase',
  ShiftService: 'ShiftService',
  ShiftRepository: 'ShiftRepository'
} as const; 