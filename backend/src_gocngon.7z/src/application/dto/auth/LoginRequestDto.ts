export interface LoginRequestDto {
  g_mabc: string; // mã bưu cục
  manv: number;
  mkhau: string;
} 